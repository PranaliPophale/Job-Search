package com.pod;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.*;
import com.pod.firebaseconfig.FirebaseUtil;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;

public class NewUser extends Application {

    private Stage primaryStage;

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        primaryStage.setTitle("Job Navigator");

        // Initialize Firebase
        FirebaseUtil.initialize();

        // Set the stage to be maximized
        primaryStage.setMaximized(true);

        // Show the login page initially
        showLoginPage();
    }

    private void showLoginPage() {
        System.out.println("Showing Login Page");
        VBox loginLayout = createFormLayout();

        Label headerLabel = new Label("JOB NAVIGATOR");
        headerLabel.setStyle("-fx-font-size: 24pt; -fx-font-weight: bold; -fx-text-fill: #fff;");
        Label subHeaderLabel = new Label("A Community Where Priority Matters");
        subHeaderLabel.setStyle("-fx-font-size: 14pt; -fx-text-fill: #cccc;");
        subHeaderLabel.setAlignment(Pos.CENTER);

        Label usernameLabel = new Label("Username/email:");
        usernameLabel.setStyle("-fx-font-size: 14pt; -fx-text-fill: #fff;");
        TextField usernameField = new TextField();
        usernameField.setMaxWidth(300);

        Label passwordLabel = new Label("Password:");
        passwordLabel.setStyle("-fx-font-size: 14pt; -fx-text-fill: #fff;");
        PasswordField passwordField = new PasswordField();
        passwordField.setMaxWidth(300);

        Button loginButton = new Button("Login");
        loginButton.setStyle("-fx-font-size: 14pt; -fx-background-color: #4CAF50; -fx-text-fill: white;");
        loginButton.setPrefWidth(300);
        loginButton.setOnAction(e -> {
            try {
                authenticateUser(usernameField.getText(), passwordField.getText());
            } catch (IOException | ExecutionException | InterruptedException ex) {
                ex.printStackTrace();
                showAlert(Alert.AlertType.ERROR, "Login Failed", "An error occurred during login.");
            }
        });

        Button signupButton = new Button("Register");
        signupButton.setStyle("-fx-font-size: 14pt; -fx-background-color: #2196F3; -fx-text-fill: white;");
        signupButton.setPrefWidth(300);
        signupButton.setOnAction(e -> showSignupPage());

        loginLayout.getChildren().addAll(headerLabel, subHeaderLabel, usernameLabel, usernameField, passwordLabel,
                passwordField, loginButton, signupButton);

        HBox root = createHBoxWithBackground(loginLayout);

        Scene loginScene = new Scene(root, 1950, 1000);
        primaryStage.setScene(loginScene);
        primaryStage.show();
    }

    private void showSignupPage() {
        System.out.println("Showing Signup Page");
        VBox signupLayout = createFormLayout();

        Label heading = new Label("Register");
        heading.setStyle("-fx-font-size: 18pt; -fx-font-weight: bold; -fx-text-fill: #fff;");

        Label fullNameLabel = new Label("Full Name:");
        fullNameLabel.setStyle("-fx-font-size: 14pt; -fx-text-fill: #fff;");
        TextField fullNameField = new TextField();
        fullNameField.setMaxWidth(300);

        Label contactLabel = new Label("Contact Number:");
        contactLabel.setStyle("-fx-font-size: 14pt; -fx-text-fill: #fff;");
        TextField contactField = new TextField();
        contactField.setMaxWidth(300);

        Label addressLabel = new Label("Address:");
        addressLabel.setStyle("-fx-font-size: 14pt; -fx-text-fill: #fff;");
        TextField addressField = new TextField();
        addressField.setMaxWidth(300);

        Label usernameLabel = new Label("Create Username:");
        usernameLabel.setStyle("-fx-font-size: 14pt; -fx-text-fill: #fff;");
        TextField usernameField = new TextField();
        usernameField.setMaxWidth(300);

        Label passwordLabel = new Label("Create Password:");
        passwordLabel.setStyle("-fx-font-size: 14pt; -fx-text-fill: #fff;");
        PasswordField passwordField = new PasswordField();
        passwordField.setMaxWidth(300);

        Label confirmPasswordLabel = new Label("Confirm Password:");
        confirmPasswordLabel.setStyle("-fx-font-size: 14pt; -fx-text-fill: #fff;");
        PasswordField confirmPasswordField = new PasswordField();
        confirmPasswordField.setMaxWidth(300);

        Button signupButton = new Button("Submit");
        signupButton.setStyle("-fx-font-size: 14pt; -fx-background-color: #4CAF50; -fx-text-fill: white;");
        signupButton.setPrefWidth(300);
        signupButton.setOnAction(e -> {
            try {
                registerUser(fullNameField.getText(), contactField.getText(), addressField.getText(),
                        usernameField.getText(), passwordField.getText());
            } catch (IOException | ExecutionException | InterruptedException ex) {
                ex.printStackTrace();
                showAlert(Alert.AlertType.ERROR, "Registration Failed", "An error occurred during registration.");
            }
        });

        Button backButton = new Button("Back");
        backButton.setStyle("-fx-font-size: 14pt; -fx-background-color: #F44336; -fx-text-fill: white;");
        backButton.setPrefWidth(300);
        backButton.setOnAction(e -> showLoginPage());

        signupLayout.getChildren().addAll(heading, fullNameLabel, fullNameField, contactLabel, contactField,
                addressLabel, addressField, usernameLabel, usernameField, passwordLabel, passwordField,
                confirmPasswordLabel, confirmPasswordField, signupButton, backButton);

        HBox root = createHBoxWithBackground(signupLayout);

        Scene registerScene = new Scene(root, 1950, 1000);
        primaryStage.setScene(registerScene);

        // Set the stage to be maximized
        primaryStage.setMaximized(true);
    }

    private VBox createFormLayout() {
        VBox layout = new VBox(15);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(20));
        layout.setStyle("-fx-background-color: rgba(0, 0, 0, 0.7); -fx-background-radius: 10;");
        return layout;
    }

    private HBox createHBoxWithBackground(VBox layout) {
        HBox root = new HBox();

        ImageView background = createBackgroundImageView("Job Search//demo//src//main//resources//img//Finalimg.jpg");
        background.setPreserveRatio(true);
        background.setFitHeight(600);

        StackPane leftPane = new StackPane(background);
        leftPane.setAlignment(Pos.CENTER_LEFT);
        leftPane.setMaxWidth(Double.MAX_VALUE);

        background.fitWidthProperty().bind(leftPane.widthProperty());
        background.fitHeightProperty().bind(leftPane.heightProperty());

        HBox.setHgrow(leftPane, javafx.scene.layout.Priority.ALWAYS);
        HBox.setHgrow(layout, javafx.scene.layout.Priority.ALWAYS);

        root.getChildren().addAll(leftPane, layout);
        HBox.setMargin(layout, new Insets(0, 20, 0, 0));

        return root;
    }

    private void openProfilePage() throws FileNotFoundException {
        System.out.println("Opening Profile Page");
        ProfilePage profilePage = new ProfilePage(primaryStage);
        primaryStage.setMaximized(true);
        profilePage.start(primaryStage);
    }

    private ImageView createBackgroundImageView(String imagePath) {
        Image backgroundImage = null;
        try {
            backgroundImage = new Image(new FileInputStream(imagePath));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return new ImageView(backgroundImage);
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void registerUser(String fullName, String contact, String address, String username, String password)
            throws IOException, ExecutionException, InterruptedException {
        Firestore db = FirebaseUtil.getFirestore();
        DocumentReference docRef = db.collection("users").document(username);

        Map<String, Object> userData = new HashMap<>();
        userData.put("fullName", fullName);
        userData.put("contact", contact);
        userData.put("address", address);
        userData.put("username", username);
        userData.put("password", password);

        ApiFuture<WriteResult> result = docRef.set(userData);
        result.get(); // Wait for the write to complete

        showAlert(Alert.AlertType.INFORMATION, "Registration Successful", "You have successfully registered!");

        openProfilePage();
    }

    private void authenticateUser(String username, String password)
            throws IOException, ExecutionException, InterruptedException {
        Firestore db = FirebaseUtil.getFirestore();
        DocumentReference docRef = db.collection("users").document(username);
        ApiFuture<DocumentSnapshot> future = docRef.get();
        DocumentSnapshot document = future.get();

        if (!document.exists()) {
            showAlert(Alert.AlertType.ERROR, "Login Failed", "Invalid username.");
        } else if (!document.getString("password").equals(password)) {
            showAlert(Alert.AlertType.ERROR, "Login Failed", "Invalid password.");
        } else {
            showAlert(Alert.AlertType.INFORMATION, "Login Successful",
                    "Welcome, " + document.getString("fullName") + "!");
            openProfilePage();
        }
    }

}
