package com.pod;
import javafx.application.Application;

public class Main {
    public static void main(String[] args) {
        
            Application.launch(NewUser.class,args);
        }
    }
