package com.pod;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class ProfilePage extends Application {

    private Stage primaryStage;

    public ProfilePage() {
    }

    public ProfilePage(Stage stage) {
        this.primaryStage = stage;
    }

    @Override
    public void start(Stage primaryStage) throws FileNotFoundException {
        if (this.primaryStage == null) {
            this.primaryStage = primaryStage;
        }

        primaryStage.setTitle("Profile Page");

        // Create a VBox for the sidebar
        VBox sidebar = new VBox();
        sidebar.setPadding(new Insets(20));
        sidebar.setSpacing(20);
        sidebar.setStyle("-fx-background-color: #336697;");

        // Add buttons to the sidebar
        Button btnNotification = new Button("Notifications");
        Button btnGenerateResume = new Button("Generate Resume");
        Button btnLogout = new Button("Logout");

        // Set button actions
        btnNotification.setOnAction(event -> showNotification());
        btnGenerateResume.setOnAction(event -> generateResume());
        btnLogout.setOnAction(event -> logout());

        sidebar.getChildren().addAll(btnNotification, btnGenerateResume, btnLogout);

        // Load the profile image
        String imagePath = "Job Search//demo//src//main//resources//img//shweta photo.jpg";
        Image profileImage = new Image(new FileInputStream(imagePath));
        ImageView profileImageView = new ImageView(profileImage);
        profileImageView.setFitWidth(200);
        profileImageView.setFitHeight(200);

        // Create a Tooltip for the profile image
        Tooltip profileTooltip = new Tooltip();
        profileTooltip.setGraphic(createProfileDetails());
        Tooltip.install(profileImageView, profileTooltip);

        // Create benefits boxes
        VBox benefitsBox = createBenefitsBox();

        // Scroll pane for benefits boxes
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setContent(benefitsBox);
        scrollPane.setFitToWidth(true);
        scrollPane.setFitToHeight(true);

        // Create a BorderPane as the main layout
        BorderPane borderPane = new BorderPane();
        borderPane.setLeft(sidebar);
        borderPane.setRight(profileImageView);
        borderPane.setCenter(scrollPane);
        BorderPane.setMargin(profileImageView, new Insets(10));
        BorderPane.setMargin(scrollPane, new Insets(20, 0, 0, 0));

        // Set the scene
        Scene scene = new Scene(borderPane, 1950, 1000);
        primaryStage.setScene(scene);
        primaryStage.setMaximized(true); // Ensure the profile page opens maximized
        primaryStage.show();
    }

    private VBox createProfileDetails() {
        VBox detailsBox = new VBox(20);
        detailsBox.setPadding(new Insets(20));
        detailsBox.setStyle("-fx-background-color: white; -fx-border-color: black; -fx-border-width: 1;");

        Text name = new Text("Name: Shweta Telawade");
        Text email = new Text("Email: shwetatelawade123@gmail.com");
        Text phone = new Text("Phone: 7499194139");

        detailsBox.getChildren().addAll(name, email, phone);
        return detailsBox;
    }

    private VBox createFancyInfoBox(String title, String jobDescription, String backgroundColor) {
        VBox box = new VBox(10);
        box.setPadding(new Insets(15));
        box.setStyle("-fx-border-color: black; -fx-border-width: 2; " + backgroundColor
                + " -fx-border-radius: 5; -fx-background-radius: 5;");

        Text titleText = new Text(title);
        titleText.setStyle("-fx-font-size: 18; -fx-font-weight: bold;");

        Text descriptionText = new Text(jobDescription);
        descriptionText.setStyle("-fx-font-size: 14;");

        VBox buttonsBox = new VBox(5);
        Button applyButton = new Button("Apply");
        Button uploadCVButton = new Button("Upload CV");

        applyButton.setOnAction(event -> {
            // Show popup message
            showAlert("Applied for " + title);
        });

        uploadCVButton.setOnAction(event -> {
            // Open file chooser for PDF file selection
            FileChooser fileChooser = new FileChooser();
            fileChooser.getExtensionFilters().addAll(
                    new FileChooser.ExtensionFilter("PDF Files", "*.pdf"));
            File selectedFile = fileChooser.showOpenDialog(primaryStage);
            if (selectedFile != null) {
                // Handle PDF upload logic here, e.g., save to server or display a success
                // message
                showAlert("CV uploaded successfully for " + title);
                // Add a small PDF icon
                ImageView pdfIcon = new ImageView(new Image(getClass().getResourceAsStream("pdf-icon.png")));
                pdfIcon.setFitWidth(20);
                pdfIcon.setFitHeight(20);
                buttonsBox.getChildren().add(pdfIcon);
            }
        });

        buttonsBox.getChildren().addAll(applyButton, uploadCVButton);

        box.getChildren().addAll(titleText, descriptionText, buttonsBox);
        return box;
    }

    private VBox createBenefitsBox() {
        VBox benefitsBox = new VBox(20); // Increased spacing for better layout
        benefitsBox.setPadding(new Insets(20));
        benefitsBox.setAlignment(Pos.TOP_CENTER);
        benefitsBox.setStyle("-fx-background-color: transparent;"); // Make background transparent

        VBox userFriendlyBox = createFancyInfoBox(
                "Amazon",
                "Job Description for Amazon",
                "-fx-background-color: linear-gradient(to top, #f5f7fa, #c3cfe2);"); // Light gradient from white to
                                                                                     // light blue
        addHoverAnimation(userFriendlyBox);

        VBox engagementBox = createFancyInfoBox(
                "Accenture",
                "Job Description for Accenture",
                "-fx-background-color: linear-gradient(to top, #f5f7fa, #c3cfe2);"); // Light gradient from lavender to
                                                                                     // light blue
        addHoverAnimation(engagementBox);

        VBox costEffectiveBox = createFancyInfoBox(
                "Cognizant",
                "Job Description for Cognizant",
                "-fx-background-color: linear-gradient(to top, #f5f7fa, #c3cfe2);"); // Light gradient from pink to
                                                                                     // light blue
        addHoverAnimation(costEffectiveBox);

        VBox anotherBox1 = createFancyInfoBox(
                "Persistent",
                "Job Description for Persistent",
                "-fx-background-color: linear-gradient(to top, #f5f7fa, #c3cfe2);");
        addHoverAnimation(anotherBox1);

        VBox anotherBox2 = createFancyInfoBox(
                "Wipro",
                "Job Description for Wipro",
                "-fx-background-color: linear-gradient(to top, #f5f7fa, #c3cfe2);");
        addHoverAnimation(anotherBox2);

        VBox anotherBox3 = createFancyInfoBox(
                "Kirloskar",
                "Job Description for Kirloskar",
                "-fx-background-color: linear-gradient(to top, #f5f7fa, #c3cfe2);");
        addHoverAnimation(anotherBox3);

        VBox anotherBox4 = createFancyInfoBox(
                "Infosys",
                "Job Description for Infosys",
                "-fx-background-color: linear-gradient(to top, #f5f7fa, #c3cfe2);");
        addHoverAnimation(anotherBox4);

        VBox anotherBox5 = createFancyInfoBox(
                "TCS",
                "Job Description for TCS",
                "-fx-background-color: linear-gradient(to top, #f5f7fa, #c3cfe2);");
        addHoverAnimation(anotherBox5);

        VBox anotherBox6 = createFancyInfoBox(
                "HCL",
                "Job Description for HCL",
                "-fx-background-color: linear-gradient(to top, #f5f7fa, #c3cfe2);");
        addHoverAnimation(anotherBox6);

        VBox anotherBox7 = createFancyInfoBox(
                "Tech Mahindra",
                "Job Description for Tech Mahindra",
                "-fx-background-color: linear-gradient(to top, #f5f7fa, #c3cfe2);");
        addHoverAnimation(anotherBox7);

        VBox anotherBox8 = createFancyInfoBox(
                "L&T",
                "Job Description for L&T",
                "-fx-background-color: linear-gradient(to top, #f5f7fa, #c3cfe2);");
        addHoverAnimation(anotherBox8);

        benefitsBox.getChildren().addAll(userFriendlyBox, engagementBox, costEffectiveBox, anotherBox1, anotherBox2,
                anotherBox3, anotherBox4, anotherBox5, anotherBox6, anotherBox7, anotherBox8);
        return benefitsBox;
    }

    private void addHoverAnimation(VBox box) {
        box.setOnMouseEntered(event -> box.setStyle(box.getStyle() + " -fx-background-color: lightgray;"));
        box.setOnMouseExited(event -> box.setStyle(box.getStyle().replace(" -fx-background-color: lightgray;", "")));
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Application Status");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showNotification() {
        showAlert("Notification button clicked");
        // Placeholder for notification logic
    }

    private void generateResume() {
        // Launch the resume generator without showing a popup message
        ResumeGenerator resumeApp = new ResumeGenerator();
        Stage resumeStage = new Stage();
        try {
            resumeApp.start(resumeStage);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void logout() {
        showAlert("Logging out...");
        // Navigate back to the login page
        primaryStage.close();
        new NewUser().start(new Stage());
    }

    public static void main(String[] args) {
        launch(args);
    }
}
