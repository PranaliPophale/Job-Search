package com.pod;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import javafx.application.Application;
import javafx.embed.swing.SwingFXUtils;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;
import javafx.stage.Screen;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class ResumeGenerator extends Application {

    private ImageView profileImageView;
    private TextField nameField;
    private TextField emailField;
    private TextField phoneField;
    private TextArea workExperienceField;
    private TextArea educationField;
    private TextField tenthPercentageField;
    private TextField twelfthPercentageField;
    private TextField schoolNameField;
    private TextField collegeNameField;
    private TextField cgpaField;
    private TextArea projectDetailsField;
    private TextField githubLinkField;
    private TextField linkedinLinkField;
    private TextArea addressField;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Resume Generator");
        primaryStage.setMaximized(true); // Set the stage to be maximized

        StackPane root = new StackPane();

        // Set background image
        try {
            FileInputStream inputStream = new FileInputStream(
                    "Job Search//demo//src//main//resources//img//Finalimg.jpg");
            Image backgroundImage = new Image(inputStream);
            BackgroundImage bgImage = new BackgroundImage(
                    backgroundImage,
                    BackgroundRepeat.NO_REPEAT,
                    BackgroundRepeat.NO_REPEAT,
                    BackgroundPosition.CENTER,
                    new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, false));
            Background background = new Background(bgImage);
            Pane backgroundPane = new Pane();
            backgroundPane.setBackground(background);
            root.getChildren().add(backgroundPane);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        // Create and style the header
        Label headerLabel = new Label("GENERATE RESUME");
        headerLabel.setStyle("-fx-font-size: 50px; -fx-font-weight: BOLD; -fx-text-fill: black;");
        headerLabel.setAlignment(Pos.TOP_CENTER);

        VBox inputFields = new VBox(10);
        inputFields.setPadding(new Insets(10));
        inputFields.setStyle("-fx-background-color: rgba(0, 0, 0, 0.7); -fx-background-radius: 10; -fx-padding: 20;");
        inputFields.setAlignment(Pos.CENTER); // Center the content within the VBox

        Label nameLabel = new Label("Full Name");
        nameLabel.setStyle("-fx-text-fill: white;");
        nameField = new TextField();
        nameField.setPromptText("Full Name");

        Label emailLabel = new Label("Email");
        emailLabel.setStyle("-fx-text-fill: white;");
        emailField = new TextField();
        emailField.setPromptText("Email");

        Label phoneLabel = new Label("Phone Number");
        phoneLabel.setStyle("-fx-text-fill: white;");
        phoneField = new TextField();
        phoneField.setPromptText("Phone Number");

        Label workExperienceLabel = new Label("Work Experience");
        workExperienceLabel.setStyle("-fx-text-fill: white;");
        workExperienceField = new TextArea();
        workExperienceField.setPromptText("Work Experience");
        workExperienceField.setPrefRowCount(5);

        Label educationLabel = new Label("Education");
        educationLabel.setStyle("-fx-text-fill: white;");
        educationField = new TextArea();
        educationField.setPromptText("Education");
        educationField.setPrefRowCount(5);

        Label tenthPercentageLabel = new Label("10th Percentage");
        tenthPercentageLabel.setStyle("-fx-text-fill: white;");
        tenthPercentageField = new TextField();
        tenthPercentageField.setPromptText("10th Percentage");

        Label twelfthPercentageLabel = new Label("12th Percentage");
        twelfthPercentageLabel.setStyle("-fx-text-fill: white;");
        twelfthPercentageField = new TextField();
        twelfthPercentageField.setPromptText("12th Percentage");

        Label schoolNameLabel = new Label("School Name");
        schoolNameLabel.setStyle("-fx-text-fill: white;");
        schoolNameField = new TextField();
        schoolNameField.setPromptText("School Name");

        Label collegeNameLabel = new Label("College Name");
        collegeNameLabel.setStyle("-fx-text-fill: white;");
        collegeNameField = new TextField();
        collegeNameField.setPromptText("College Name");

        Label cgpaLabel = new Label("CGPA");
        cgpaLabel.setStyle("-fx-text-fill: white;");
        cgpaField = new TextField();
        cgpaField.setPromptText("CGPA");

        Label projectDetailsLabel = new Label("Project Details");
        projectDetailsLabel.setStyle("-fx-text-fill: white;");
        projectDetailsField = new TextArea();
        projectDetailsField.setPromptText("Project Details");
        projectDetailsField.setPrefRowCount(5);

        Label githubLinkLabel = new Label("GitHub Link");
        githubLinkLabel.setStyle("-fx-text-fill: white;");
        githubLinkField = new TextField();
        githubLinkField.setPromptText("GitHub Link");

        Label linkedinLinkLabel = new Label("LinkedIn Link");
        linkedinLinkLabel.setStyle("-fx-text-fill: white;");
        linkedinLinkField = new TextField();
        linkedinLinkField.setPromptText("LinkedIn Link");

        Label addressLabel = new Label("Address");
        addressLabel.setStyle("-fx-text-fill: white;");
        addressField = new TextArea();
        addressField.setPromptText("Address");
        addressField.setPrefRowCount(3);

        Button uploadPhotoButton = new Button("Upload Photo");
        uploadPhotoButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
        profileImageView = new ImageView();
        profileImageView.setFitHeight(100);
        profileImageView.setFitWidth(100);

        Button saveAsPdfButton = new Button("Save as PDF");
        saveAsPdfButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");

        uploadPhotoButton.setOnAction(e -> uploadPhoto());
        saveAsPdfButton.setOnAction(e -> {
            try {
                saveAsPdf();
                // Show success message
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Success");
                alert.setHeaderText(null);
                alert.setContentText("PDF successfully saved!");
                alert.showAndWait();
            } catch (DocumentException | IOException ex) {
                ex.printStackTrace();
            }
        });

        inputFields.getChildren().addAll(
                nameLabel, nameField,
                emailLabel, emailField,
                phoneLabel, phoneField,
                workExperienceLabel, workExperienceField,
                educationLabel, educationField,
                tenthPercentageLabel, tenthPercentageField,
                twelfthPercentageLabel, twelfthPercentageField,
                schoolNameLabel, schoolNameField,
                collegeNameLabel, collegeNameField,
                cgpaLabel, cgpaField,
                projectDetailsLabel, projectDetailsField,
                githubLinkLabel, githubLinkField,
                linkedinLinkLabel, linkedinLinkField,
                addressLabel, addressField,
                uploadPhotoButton, profileImageView,
                saveAsPdfButton);

        // Center the VBox
        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.add(inputFields, 0, 1); // Add VBox below the header

        // Add the header to the gridPane
        gridPane.add(headerLabel, 0, 0);
        GridPane.setMargin(headerLabel, new Insets(0, 0, 90, 90)); // Add margin below the header

        ScrollPane scrollPane = new ScrollPane(gridPane);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background: transparent; -fx-background-color: transparent;");

        StackPane.setAlignment(scrollPane, Pos.CENTER);
        root.getChildren().add(scrollPane);

        // Set scene size based on the screen size
        double screenWidth = Screen.getPrimary().getBounds().getWidth();
        double screenHeight = Screen.getPrimary().getBounds().getHeight();
        Scene scene = new Scene(root, screenWidth * 0.4, screenHeight * 0.8);

        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void uploadPhoto() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg"));
        File selectedFile = fileChooser.showOpenDialog(null);
        if (selectedFile != null) {
            Image profileImage = new Image(selectedFile.toURI().toString());
            profileImageView.setImage(profileImage);
        }
    }

    private void saveAsPdf() throws DocumentException, IOException {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF Files", "*.pdf"));
        File saveFile = fileChooser.showSaveDialog(null);
        if (saveFile != null) {
            Document document = new Document();
            PdfWriter.getInstance(document, new FileOutputStream(saveFile));
            document.open();

            // Create a table with a single column for the photo and information
            PdfPTable table = new PdfPTable(1);
            table.setWidthPercentage(100);
            table.setSpacingBefore(10f);
            table.setSpacingAfter(10f);

            // Add the profile image if available
            if (profileImageView.getImage() != null) {
                com.itextpdf.text.Image profileImage = com.itextpdf.text.Image
                        .getInstance(SwingFXUtils.fromFXImage(profileImageView.getImage(), null), null);
                profileImage.scaleToFit(100, 100);
                PdfPCell imageCell = new PdfPCell(profileImage);
                imageCell.setBorder(PdfPCell.NO_BORDER);
                imageCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                table.addCell(imageCell);
            }

            // Add information cells below the image
            table.addCell(createInfoCell("Full Name: " + nameField.getText()));
            table.addCell(createInfoCell("Email: " + emailField.getText()));
            table.addCell(createInfoCell("Phone Number: " + phoneField.getText()));
            table.addCell(createInfoCell("Work Experience: " + workExperienceField.getText()));
            table.addCell(createInfoCell("Education: " + educationField.getText()));
            table.addCell(createInfoCell("10th Percentage: " + tenthPercentageField.getText()));
            table.addCell(createInfoCell("12th Percentage: " + twelfthPercentageField.getText()));
            table.addCell(createInfoCell("School Name: " + schoolNameField.getText()));
            table.addCell(createInfoCell("College Name: " + collegeNameField.getText()));
            table.addCell(createInfoCell("CGPA: " + cgpaField.getText()));
            table.addCell(createInfoCell("Project Details: " + projectDetailsField.getText()));
            table.addCell(createInfoCell("GitHub Link: " + githubLinkField.getText()));
            table.addCell(createInfoCell("LinkedIn Link: " + linkedinLinkField.getText()));
            table.addCell(createInfoCell("Address: " + addressField.getText()));

            // Add the table to the document
            document.add(table);

            document.close();
        }
    }

    private PdfPCell createInfoCell(String text) {
        PdfPCell cell = new PdfPCell(new Paragraph(text, FontFactory.getFont(FontFactory.HELVETICA, 12)));
        cell.setBorder(PdfPCell.NO_BORDER);
        cell.setPadding(5);
        return cell;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
