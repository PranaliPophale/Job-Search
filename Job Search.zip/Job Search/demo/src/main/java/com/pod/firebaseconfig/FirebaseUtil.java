package com.pod.firebaseconfig;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.firestore.Firestore;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.cloud.FirestoreClient;

import java.io.FileInputStream;
import java.io.IOException;

public class FirebaseUtil {
    private static Firestore firestore;

    @SuppressWarnings("deprecation")
    public static void initialize() {
        try {
            FileInputStream serviceAccount = new FileInputStream("demo\\src\\main\\resources\\img\\jobsearch.json");

            FirebaseOptions options = new FirebaseOptions.Builder()
                    .setCredentials(GoogleCredentials.fromStream(serviceAccount))
                    .build();

            FirebaseApp.initializeApp(options);
            firestore = FirestoreClient.getFirestore();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Firestore getFirestore() {
        return firestore;
    }
}
